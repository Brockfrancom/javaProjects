public class TreeNode {
    int x;
    TreeNode  left;
    TreeNode  right;
}
