In a readme.txt file turned in with your assignment, answer the following
questions regarding the analysis of running time and memory usage.


The runtime is approximately O(N). The memory usage is low, as only
3 lists are used.


