/*
Brock Francom
A02052161
CS-2410
Andrew Brim
1/29/2019

This class is used for creating a Parent class Shape
 */
public class Shape {
    public double getArea() {
        return 0;
    }
}
